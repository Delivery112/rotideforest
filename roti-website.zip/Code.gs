/**
 * Roti De Forest — ระบบรับออเดอร์เดลิเวอรี่หลายสาขา (Google Apps Script)
 * ------------------------------------------------------------------
 * วางโค้ดนี้ใน Extensions > Apps Script ของ Google Sheet ร้าน
 * แล้ว Deploy เป็น Web app (Execute as: Me, Who has access: Anyone)
 *
 * Script Properties (Project Settings > Script properties):
 *   ADMIN_PIN          (จำเป็น)  รหัสเจ้าของร้าน — เห็นออเดอร์ทุกสาขา (แนะนำ 6 หลักขึ้นไป)
 *   PIN_PATTANI, PIN_SAIBURI, PIN_TALATKAO, PIN_NARATHIWAT, PIN_LAHAN, PIN_RUESO, PIN_HATYAI
 *                      (ไม่บังคับ) รหัสของแต่ละสาขา — เห็นเฉพาะออเดอร์ของสาขาตัวเอง
 *                      รหัสแต่ละสาขาต้องไม่ซ้ำกัน และไม่ซ้ำกับ ADMIN_PIN
 *   LINE_CHANNEL_TOKEN (ไม่บังคับ) Channel access token ของ LINE OA สำหรับแจ้งเตือนออเดอร์ใหม่
 *   LINE_TO            (ไม่บังคับ) userId/groupId ที่รับแจ้งเตือนทุกสาขา (เช่น เจ้าของร้าน)
 *   LINE_TO_PATTANI ... LINE_TO_HATYAI (ไม่บังคับ) groupId ของกลุ่ม LINE แต่ละสาขา
 */

const SHEET_NAME = 'Orders';
const TZ = 'Asia/Bangkok';
const HEADERS = [
  'orderId', 'createdAt', 'status', 'mode', 'name', 'phone',
  'address', 'gpsLink', 'note', 'payment', 'items', 'total', 'updatedAt',
  'branch', 'distanceKm', 'distanceCheck'
];
const COL = HEADERS.reduce((m, h, i) => (m[h] = i, m), {});
const STATUSES = ['new', 'cooking', 'ready', 'done', 'cancelled'];
const STATUS_TH = {
  new: 'ออเดอร์ใหม่', cooking: 'กำลังทำ', ready: 'พร้อมส่ง/พร้อมรับ',
  done: 'เสร็จสิ้น', cancelled: 'ยกเลิก'
};
// ===== สาขา =====
// id ต้องตรงกับใน index.html / lat,lng ใช้คำนวณรัศมีจัดส่ง
const DELIVERY_RADIUS_KM = 5;
const BRANCHES = {
  pattani:    { code: 'PTN', name: 'สาขาปัตตานี',     lat: 6.878812, lng: 101.247438 },
  saiburi:    { code: 'SBR', name: 'สาขาสายบุรี',     lat: 6.701713, lng: 101.620391 },
  talatkao:   { code: 'YLA', name: 'สาขาตลาดเก่า',     lat: 6.569937, lng: 101.296312 },
  narathiwat: { code: 'NRT', name: 'สาขานราธิวาส',    lat: 6.403238, lng: 101.821922 },
  lahan:      { code: 'LHN', name: 'สาขาปตท.ละหาร',   lat: 6.403688, lng: 101.730438 },
  rueso:      { code: 'RSO', name: 'สาขารือเสาะ',      lat: 6.381063, lng: 101.510188 },
  hatyai:     { code: 'HDY', name: 'สาขาหาดใหญ่',     lat: 6.994563, lng: 100.503062 }
};
const DEFAULT_BRANCH = 'pattani'; // ออเดอร์เก่าที่ยังไม่มีสาขา

const PAYMENTS = ['โอนเงินพร้อมเพย์ (แนบสลิปในแชท)']; // ไม่มีเก็บเงินปลายทาง

// ราคาจริงฝั่งระบบ — ระบบคิดยอดจากตารางนี้ ไม่เชื่อราคาที่ส่งมาจากหน้าเว็บ
// ถ้าแก้เมนู/ราคาในหน้า index.html ต้องแก้ที่นี่ให้ตรงกันด้วย
// ===== เมนูมื้อเช้า (ขายถึงเที่ยง) และเมนูเฉพาะสาขา =====
const MORNING_START_HOUR = 5, MORNING_END_HOUR = 12;
const MORNING_IDS = [36, 109, 120, 121, 122, 123, 124, 125];
const BRANCH_ONLY = { 125: ['pattani'] }; // ปาท่องโก๋ เฉพาะสาขาปัตตานี

const MENU = {
  1: { name: "โรตีแกงมัสมั่น+ไข่ดาว", price: 39 },
  2: { name: "โรตีแกงเขียวหวาน+ไข่ดาว", price: 39 },
  3: { name: "โรตีแกงสองสหาย+ไข่ดาว", price: 49 },
  4: { name: "โรตีอเมริกันเบรคฟาสต์", price: 45 },
  5: { name: "มะตะบะเนื้อโคขุน", price: 65 },
  6: { name: "โรตีสลัดทูน่า", price: 55 },
  7: { name: "โรตีข้าวโพด", price: 45 },
  8: { name: "โรตีฝอยทอง", price: 45 },
  9: { name: "โรตีลูกตาล", price: 45 },
  10: { name: "โรตีไข่", price: 30 },
  11: { name: "โรตีกล้วย", price: 40 },
  12: { name: "โรตีนูเทล่า", price: 55 },
  13: { name: "โรตีกล้วยนูเทล่า", price: 65 },
  14: { name: "โรตีชีส", price: 60 },
  15: { name: "โรตีไก่หยองแฮมชีส", price: 65 },
  16: { name: "โรตีพิซซ่า", price: 65 },
  17: { name: "โรตีพิซซ่าทะเล", price: 85 },
  18: { name: "โรตีธรรมดา", price: 15 },
  19: { name: "โรตีไมโล", price: 25 },
  20: { name: "โรตีกรอบนม", price: 35 },
  21: { name: "โรตีกรอบไมโล", price: 40 },
  22: { name: "โรตีกรอบนูเทล่า", price: 60 },
  23: { name: "ขนมปังอบไอน้ำ", price: 50 },
  24: { name: "โรตีเปล่า", price: 20 },
  25: { name: "ไข่ดาว", price: 10 },
  26: { name: "กายาโทสต์", price: 50 },
  27: { name: "ข้าวต้มปลาอินทรีย์", price: 55 },
  28: { name: "ข้าวต้มปลากะพง", price: 55 },
  29: { name: "ข้าวต้มเนื้อ", price: 59 },
  30: { name: "ข้าวต้มกุ้ง", price: 50 },
  31: { name: "ข้าวต้มไก่", price: 39 },
  32: { name: "ข้าวต้มกะเพราเนื้อ", price: 59 },
  33: { name: "ข้าวต้มกะเพราไก่", price: 49 },
  34: { name: "ข้าวไก่ทอดอินโด (Nasi Ayam Penyet) M", price: 75 },
  108: { name: "ข้าวไก่ทอดอินโด (Nasi Ayam Penyet) L", price: 95 },
  35: { name: "Nasi ayam gepuk M", price: 109 },
  36: { name: "นาซิดาแฆ", price: 40 },
  109: { name: "ข้าวยำอัญชัญ (ไข่ต้ม)", price: 35 },
  37: { name: "ข้าวกะเพราเนื้อ+ไข่ดาว", price: 69 },
  38: { name: "ข้าวกะเพราไก่+ไข่ดาว", price: 59 },
  39: { name: "ข้าวผัดทะเล", price: 69 },
  40: { name: "ข้าวต้มยำ+ไข่เจียว", price: 75 },
  41: { name: "ข้าวเครื่องแกง+ไข่ดาว", price: 69 },
  42: { name: "ข้าวยำไก่แซ่บ+ไข่ดาว", price: 69 },
  43: { name: "ข้าวแกงส้ม+ไข่เจียว", price: 75 },
  44: { name: "ข้าวไข่เจียว", price: 25 },
  45: { name: "ข้าวไข่เจียวทรงเครื่อง", price: 35 },
  46: { name: "ข้าวไข่เจียวกุ้งสับ", price: 49 },
  47: { name: "ข้าวเปล่า", price: 10 },
  48: { name: "เนื้อย่าง 1ไม้", price: 17 },
  49: { name: "เนื้อย่าง 7ไม้", price: 119 },
  50: { name: "ไก่ย่าง 1ไม้", price: 15 },
  51: { name: "ไก่ย่าง 7ไม้", price: 105 },
  52: { name: "เกี้ยวซ่า", price: 65 },
  53: { name: "ซาลาเปาลาวาไข่เค็ม (ชุด 2ลูก)", price: 50 },
  54: { name: "ซาลาเปาลาวาชาไทย (ชุด 2ลูก)", price: 50 },
  55: { name: "ซาลาเปาลาวาช็อคโกแลต (ชุด 2ลูก)", price: 50 },
  56: { name: "ซาลาเปาลาวามันม่วง (ชุด 2ลูก)", price: 50 },
  57: { name: "ไข่ลวก(2ฟอง)", price: 30 },
  110: { name: "กือโป๊ะ", price: 35 },
  111: { name: "ไก่ป๊อป", price: 45 },
  112: { name: "นักเก็ตไก่", price: 45 },
  113: { name: "ไก่จ๊อ", price: 45 },
  114: { name: "เอ็นไก่ทอด", price: 65 },
  115: { name: "เฟรนช์ฟรายส์ทอด", price: 45 },
  116: { name: "เฟรนช์ฟรายส์ชีส", price: 55 },
  117: { name: "ไส้กรอกอีสานทอด", price: 45 },
  119: { name: "รวมทอด", price: 75 },
  58: { name: "ชาดำร้อน", price: 15 },
  59: { name: "ชาดำเย็น", price: 25 },
  60: { name: "ชามะนาวร้อน", price: 30 },
  61: { name: "ชามะนาวเย็น", price: 35 },
  62: { name: "ชา English Breakfast ร้อน", price: 30 },
  63: { name: "ชา English Breakfast เย็น", price: 35 },
  64: { name: "ชาไทยร้อน", price: 25 },
  65: { name: "ชาไทยเย็น", price: 35 },
  66: { name: "ชานมสดร้อน", price: 30 },
  67: { name: "ชานมสดเย็น", price: 35 },
  68: { name: "ชาเขียวร้อน", price: 20 },
  69: { name: "ชาเขียวเย็น", price: 30 },
  70: { name: "ชาเขียวนมสดร้อน", price: 30 },
  71: { name: "ชาเขียวนมสดเย็น", price: 35 },
  72: { name: "ไมโลร้อน", price: 25 },
  73: { name: "ไมโลเย็น", price: 35 },
  74: { name: "โอวัลตินร้อน", price: 20 },
  75: { name: "โอวัลตินเย็น", price: 35 },
  76: { name: "โอวัลตินนมสดร้อน", price: 35 },
  77: { name: "โอวัลตินนมสดเย็น", price: 40 },
  78: { name: "โอวัลตินดิบ (เย็น)", price: 40 },
  79: { name: "โกโก้ร้อน", price: 25 },
  80: { name: "โกโก้เย็น", price: 35 },
  81: { name: "โกโก้นมสดร้อน", price: 35 },
  82: { name: "โกโก้นมสดเย็น", price: 45 },
  83: { name: "นมสดร้อน", price: 25 },
  84: { name: "นมสดเย็น", price: 35 },
  85: { name: "นมสดไวท์ช็อคร้อน", price: 30 },
  86: { name: "นมสดไวท์ช็อคเย็น", price: 40 },
  87: { name: "นมสดคาราเมลร้อน", price: 30 },
  88: { name: "นมสดคาราเมลเย็น", price: 40 },
  89: { name: "นมชมพูเย็น", price: 35 },
  90: { name: "เฉาก๊วยนมสด (เย็น)", price: 45 },
  91: { name: "เอสเพรสโซ่ร้อน", price: 40 },
  92: { name: "เอสเพรสโซ่เย็น", price: 50 },
  93: { name: "มอคค่าร้อน", price: 40 },
  94: { name: "มอคค่าเย็น", price: 50 },
  95: { name: "ลาเต้ร้อน", price: 40 },
  96: { name: "ลาเต้เย็น", price: 50 },
  97: { name: "อเมริกาโน่ร้อน", price: 40 },
  98: { name: "อเมริกาโน่เย็น", price: 50 },
  99: { name: "คาราเมลมัคคิอาโต้ร้อน", price: 40 },
  100: { name: "คาราเมลมัคคิอาโต้เย็น", price: 50 },
  101: { name: "คาปูชิโน่ร้อน", price: 40 },
  102: { name: "คาปูชิโน่เย็น", price: 50 },
  103: { name: "สตอเบอรี่เฟรชโซดา (เย็น)", price: 35 },
  104: { name: "ฮันนี่เลม่อนโซดา (เย็น)", price: 35 },
  105: { name: "อิตาเลี่ยนชามะนาว (เย็น)", price: 35 },
  106: { name: "บลูเลม่อนฮาวายโซดา (เย็น)", price: 35 },
  107: { name: "อิตาเลี่ยนแมงโก้เฟรชโซดา (เย็น)", price: 35 },
  126: { name: "ชาเขียวเงาะ (เย็น)", price: 45 },
  127: { name: "ชาเงาะ (เย็น)", price: 45 },
  128: { name: "โรตีแกงมัสมั่นเนื้อน่องลาย", price: 65 },
  129: { name: "ข้าวแกงมัสมั่นเนื้อน่องลาย", price: 75 },
  120: { name: "ข้าวมันไก่ทอด", price: 40 },
  121: { name: "ข้าวมันไก่ผสม (ไก่ทอด+ไก่ต้ม)", price: 45 },
  122: { name: "ข้าวเหนียวดำไก่หวาน", price: 59 },
  123: { name: "ข้าวเหนียวดำเนื้อแดดเดียว", price: 69 },
  124: { name: "ข้าวเหนียวดำปลาแดดเดียว", price: 69 },
  125: { name: "ปาท่องโก๋ (สังขยาใบเตย)", price: 35 },
};

/* ============================ HTTP ============================ */

function doGet(e) {
  const p = (e && e.parameter) || {};
  try {
    if (p.action === 'status') return json_(getStatus_(p.id));
    return json_({ ok: true, service: 'roti-deforest-orders' });
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

function doPost(e) {
  let body;
  try {
    body = JSON.parse(e.postData.contents);
  } catch (_) {
    return json_({ ok: false, error: 'ข้อมูลไม่ถูกต้อง' });
  }
  // ข้อความจาก LINE (Webhook): ใช้หา Group ID ของกลุ่มสาขา
  if (Array.isArray(body.events)) {
    try { handleLineEvents_(body.events); } catch (err) { console.warn(err); }
    return json_({ ok: true });
  }
  try {
    switch (body.action) {
      case 'create':       return json_(createOrder_(body.order || {}));
      case 'login': {
        const scope = checkPin_(body.pin);
        return json_({ ok: true, scope: scope, branchName: scope === 'ALL' ? 'ทุกสาขา' : BRANCHES[scope].name });
      }
      case 'list':         return json_(listOrders_(body.days, checkPin_(body.pin)));
      case 'updateStatus': return json_(updateStatus_(body.orderId, body.status, checkPin_(body.pin)));
      default:             return json_({ ok: false, error: 'unknown_action' });
    }
  } catch (err) {
    return json_({ ok: false, error: String(err.message || err) });
  }
}

/* ============================ Actions ============================ */

function createOrder_(o) {
  const name = str_(o.name, 60);
  const phone = String(o.phone || '').replace(/[^0-9]/g, '');
  const mode = o.mode === 'pickup' ? 'pickup' : 'delivery';
  const address = mode === 'delivery' ? str_(o.address, 300) : '';
  const note = str_(o.note, 200);
  const payment = PAYMENTS.indexOf(o.payment) >= 0 ? o.payment : PAYMENTS[0];
  let gpsLink = String(o.gpsLink || '');
  if (mode !== 'delivery' || !/^https:\/\/maps\.google\.com\/\?q=-?\d{1,3}\.\d+,-?\d{1,3}\.\d+$/.test(gpsLink)) gpsLink = '';

  const branchId = String(o.branch || '');
  const branch = BRANCHES[branchId];
  if (!branch) throw new Error('กรุณาเลือกสาขา');

  // ตรวจรัศมีจัดส่งจากพิกัด GPS ของลูกค้า
  let distanceKm = '';
  let distanceCheck = '';
  if (mode === 'delivery') {
    if (gpsLink) {
      const m = gpsLink.match(/q=(-?[\d.]+),(-?[\d.]+)/);
      distanceKm = Math.round(distanceKm_(branch.lat, branch.lng, Number(m[1]), Number(m[2])) * 10) / 10;
      if (distanceKm > DELIVERY_RADIUS_KM) {
        throw new Error('อยู่นอกพื้นที่จัดส่งของ' + branch.name + ' (ห่าง ' + distanceKm + ' กม. เกิน ' + DELIVERY_RADIUS_KM + ' กม.)');
      }
      distanceCheck = 'ok';
    } else {
      distanceCheck = 'unverified'; // ไม่มี GPS — ร้านต้องตรวจที่อยู่เอง
    }
  }

  if (!name) throw new Error('กรุณากรอกชื่อผู้สั่ง');
  if (phone.length < 9 || phone.length > 10) throw new Error('เบอร์โทรไม่ถูกต้อง');
  if (mode === 'delivery' && !address && !gpsLink) throw new Error('กรุณาระบุที่อยู่จัดส่ง');

  // คิดราคาใหม่จากเมนูฝั่งระบบ
  const items = [];
  let total = 0;
  const bkkHour = Number(Utilities.formatDate(new Date(), 'Asia/Bangkok', 'H'));
  const morningOpen = bkkHour >= MORNING_START_HOUR && bkkHour < MORNING_END_HOUR;
  (Array.isArray(o.items) ? o.items : []).slice(0, 30).forEach(it => {
    const m = MENU[Number(it.id)];
    const qty = Math.floor(Number(it.qty));
    if (!m || !(qty >= 1 && qty <= 50)) return;
    if (MORNING_IDS.indexOf(Number(it.id)) >= 0 && !morningOpen) throw new Error(m.name + ' เป็นเมนูมื้อเช้า ขาย 05:00–12:00 เท่านั้น');
    const only = BRANCH_ONLY[Number(it.id)];
    if (only && only.indexOf(branchId) < 0) throw new Error(m.name + ' ไม่มีขายที่' + branch.name);
    const itemNote = safe_(str_(it.note, 100));
    items.push({ id: Number(it.id), name: m.name, price: m.price, qty: qty, note: itemNote });
    total += m.price * qty;
  });
  if (!items.length) throw new Error('ตะกร้าว่าง');

  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const now = new Date();
    const orderId = nextOrderId_(now, branch.code);
    const sheet = getSheet_();
    const row = [];
    row[COL.orderId] = orderId;
    row[COL.createdAt] = now.toISOString();
    row[COL.status] = 'new';
    row[COL.mode] = mode;
    row[COL.name] = safe_(name);
    row[COL.phone] = phone;
    row[COL.address] = safe_(address);
    row[COL.gpsLink] = gpsLink;
    row[COL.note] = safe_(note);
    row[COL.payment] = payment;
    row[COL.items] = JSON.stringify(items);
    row[COL.total] = total;
    row[COL.updatedAt] = now.toISOString();
    row[COL.branch] = branchId;
    row[COL.distanceKm] = distanceKm;
    row[COL.distanceCheck] = distanceCheck;
    sheet.appendRow(row);

    notifyLine_(orderId, branchId, { name, phone, mode, address, gpsLink, note, payment, items, total, distanceKm, distanceCheck });
    return { ok: true, orderId: orderId, total: total, status: 'new', branch: branchId, distanceKm: distanceKm };
  } finally {
    lock.releaseLock();
  }
}

function getStatus_(id) {
  if (!id) throw new Error('ไม่พบเลขออเดอร์');
  const found = findRow_(String(id));
  if (!found) throw new Error('ไม่พบออเดอร์นี้');
  const r = found.values;
  // ส่งกลับเฉพาะข้อมูลที่ไม่ใช่ข้อมูลส่วนตัว
  return {
    ok: true,
    orderId: r[COL.orderId],
    status: r[COL.status],
    statusText: STATUS_TH[r[COL.status]] || r[COL.status],
    mode: r[COL.mode],
    total: Number(r[COL.total]),
    branchName: (BRANCHES[branchOf_(r)] || {}).name || '',
    updatedAt: r[COL.updatedAt]
  };
}

function listOrders_(days, scope) {
  const d = Math.min(Math.max(Number(days) || 2, 1), 31);
  const since = Date.now() - d * 86400000;
  const sheet = getSheet_();
  const last = sheet.getLastRow();
  if (last < 2) return { ok: true, orders: [] };
  // อ่านแค่ช่วงท้ายของชีต (ออเดอร์ใหม่อยู่ล่างสุด)
  const start = Math.max(2, last - 999);
  const values = sheet.getRange(start, 1, last - start + 1, HEADERS.length).getValues();
  const orders = [];
  for (let i = values.length - 1; i >= 0; i--) {
    const r = values[i];
    const t = Date.parse(r[COL.createdAt]);
    if (!r[COL.orderId] || isNaN(t) || t < since) continue;
    const b = branchOf_(r);
    if (scope !== 'ALL' && b !== scope) continue;
    let items = [];
    try { items = JSON.parse(r[COL.items]); } catch (_) {}
    orders.push({
      orderId: r[COL.orderId], createdAt: r[COL.createdAt], status: r[COL.status],
      mode: r[COL.mode], name: unsafe_(r[COL.name]), phone: String(r[COL.phone]),
      address: unsafe_(r[COL.address]), gpsLink: r[COL.gpsLink], note: unsafe_(r[COL.note]),
      payment: r[COL.payment], items: items, total: Number(r[COL.total]), updatedAt: r[COL.updatedAt],
      branch: b, distanceKm: r[COL.distanceKm] === '' ? null : Number(r[COL.distanceKm]),
      distanceCheck: r[COL.distanceCheck] || ''
    });
  }
  const branches = Object.keys(BRANCHES).map(id => ({ id: id, name: BRANCHES[id].name }));
  return { ok: true, scope: scope, branches: branches, orders: orders, serverTime: new Date().toISOString() };
}

function updateStatus_(orderId, status, scope) {
  if (STATUSES.indexOf(status) < 0) throw new Error('สถานะไม่ถูกต้อง');
  const lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try {
    const found = findRow_(String(orderId));
    if (!found) throw new Error('ไม่พบออเดอร์นี้');
    if (scope !== 'ALL' && branchOf_(found.values) !== scope) throw new Error('ออเดอร์นี้ไม่ใช่ของสาขาคุณ');
    const now = new Date().toISOString();
    found.sheet.getRange(found.row, COL.status + 1).setValue(status);
    found.sheet.getRange(found.row, COL.updatedAt + 1).setValue(now);
    return { ok: true, orderId: orderId, status: status, updatedAt: now };
  } finally {
    lock.releaseLock();
  }
}

/* ============================ Helpers ============================ */

function checkPin_(pin) {
  const props = PropertiesService.getScriptProperties();
  const real = props.getProperty('ADMIN_PIN');
  if (!real) throw new Error('ยังไม่ได้ตั้งค่า ADMIN_PIN ใน Script properties');
  const cache = CacheService.getScriptCache();
  const fails = Number(cache.get('pin_fails') || 0);
  if (fails >= 10) throw new Error('ใส่รหัสผิดหลายครั้ง กรุณารอ 10 นาที');
  pin = String(pin || '');
  if (pin && pin === real) return 'ALL';
  for (const id in BRANCHES) {
    const bp = props.getProperty('PIN_' + id.toUpperCase());
    if (pin && bp && pin === bp) return id;
  }
  cache.put('pin_fails', String(fails + 1), 600);
  throw new Error('รหัสไม่ถูกต้อง');
}

function branchOf_(r) { return BRANCHES[r[COL.branch]] ? String(r[COL.branch]) : DEFAULT_BRANCH; }

// ระยะทางเส้นตรงระหว่าง 2 พิกัด (กม.)
function distanceKm_(lat1, lng1, lat2, lng2) {
  const R = 6371, toRad = d => d * Math.PI / 180;
  const dLat = toRad(lat2 - lat1), dLng = toRad(lng2 - lng1);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function nextOrderId_(now, code) {
  const props = PropertiesService.getScriptProperties();
  const day = Utilities.formatDate(now, TZ, 'yyMMdd');
  const key = 'seq_' + code + '_' + day;
  const n = Number(props.getProperty(key) || 0) + 1;
  props.setProperty(key, String(n));
  return code + day.slice(2) + '-' + ('00' + n).slice(-3); // เช่น PTN1121-007 (สาขา + เดือนวัน + ลำดับ)
}

function findRow_(orderId) {
  const sheet = getSheet_();
  const last = sheet.getLastRow();
  if (last < 2) return null;
  const ids = sheet.getRange(2, 1, last - 1, 1).getValues();
  for (let i = ids.length - 1; i >= 0; i--) {
    if (String(ids[i][0]) === orderId) {
      const row = i + 2;
      return { sheet, row, values: sheet.getRange(row, 1, 1, HEADERS.length).getValues()[0] };
    }
  }
  return null;
}

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
    sheet.setFrozenRows(1);
    // เก็บทุกคอลัมน์เป็นข้อความ (กันเลข 0 หน้าเบอร์โทรหาย) ยกเว้นยอดรวม
    sheet.getRange('A:P').setNumberFormat('@');
    sheet.getRange(1, COL.total + 1, sheet.getMaxRows(), 1).setNumberFormat('0');
  } else if (sheet.getLastColumn() < HEADERS.length) {
    // ชีตจากเวอร์ชันเดิม: เติมหัวคอลัมน์ใหม่ (สาขา/ระยะ) ต่อท้าย
    sheet.getRange(1, 1, 1, HEADERS.length).setValues([HEADERS]).setFontWeight('bold');
    sheet.getRange(1, COL.branch + 1, sheet.getMaxRows(), 3).setNumberFormat('@');
  }
  return sheet;
}

function notifyLine_(orderId, branchId, o) {
  const props = PropertiesService.getScriptProperties();
  const token = props.getProperty('LINE_CHANNEL_TOKEN');
  if (!token) return;
  const targets = [props.getProperty('LINE_TO_' + branchId.toUpperCase()), props.getProperty('LINE_TO')]
    .filter((v, i, a) => v && a.indexOf(v) === i);
  if (!targets.length) return;
  const SEP = '──────────';
  const count = o.items.reduce((n, it) => n + it.qty, 0);
  const when = Utilities.formatDate(new Date(), 'Asia/Bangkok', 'dd/MM HH:mm');
  const lines = o.items.map((it, i) => `${i + 1}) ${it.name} x${it.qty}  ${it.price * it.qty}฿` + (it.note ? `\n    ${it.note}` : '')).join('\n');
  const text = [
    `🧾 ออเดอร์ใหม่ ${orderId}`,
    `🕒 ${when} | ${o.mode === 'delivery' ? 'ส่งทันที' : 'รับที่ร้าน'}`,
    SEP,
    lines,
    SEP,
    `รวม ${count} รายการ  ค่าอาหาร ${o.total}฿`,
    o.mode === 'delivery' ? 'ค่าส่ง ฟรี' : '',
    `💰 ยอดโอน ${o.total}฿`,
    '⏳ ลูกค้าได้ QR ก่อนกดสั่ง — เช็กยอดในบัญชีก่อนทำ',
    SEP,
    `👤 ${o.name}  📞 ${o.phone}`,
    o.mode === 'delivery' ? `📍 ${o.address || '-'}` : `🏠 รับที่${BRANCHES[branchId].name}`,
    o.mode === 'delivery' ? (o.gpsLink ? `🗺️ ${o.gpsLink}  (${o.distanceKm} กม.)` : '⚠️ ไม่มีพิกัด GPS กรุณาตรวจระยะก่อนรับออเดอร์') : '',
    o.note ? `📝 ${o.note}` : ''
  ].filter(Boolean).join('\n');
  targets.forEach(to => {
    try {
      UrlFetchApp.fetch('https://api.line.me/v2/bot/message/push', {
        method: 'post',
        contentType: 'application/json',
        headers: { Authorization: 'Bearer ' + token },
        payload: JSON.stringify({ to: to, messages: [{ type: 'text', text: text.slice(0, 4900) }] }),
        muteHttpExceptions: true
      });
    } catch (err) {
      console.warn('LINE push failed: ' + err);
    }
  });
}

/**
 * พิมพ์ "groupid" ในกลุ่ม LINE ที่มีบัญชีร้านอยู่ บอทจะตอบ Group ID ของกลุ่มนั้นกลับมา
 * (ใช้ reply ไม่กินโควตาข้อความ)
 */
function handleLineEvents_(events) {
  const token = PropertiesService.getScriptProperties().getProperty('LINE_CHANNEL_TOKEN');
  if (!token) return;
  events.forEach(ev => {
    if (ev.type !== 'message' || !ev.message || ev.message.type !== 'text' || !ev.replyToken) return;
    const txt = String(ev.message.text || '').trim().toLowerCase().replace(/\s+/g, '');
    if (txt !== 'groupid' && txt !== 'ไอดีกลุ่ม') return;
    const src = ev.source || {};
    const id = src.groupId || src.roomId || src.userId || '';
    const kind = src.groupId ? 'Group ID ของกลุ่มนี้' : src.roomId ? 'Room ID ของห้องนี้' : 'User ID ของคุณ';
    const branches = Object.keys(BRANCHES).map(k => 'LINE_TO_' + k.toUpperCase() + ' = ' + BRANCHES[k].name).join('\n');
    UrlFetchApp.fetch('https://api.line.me/v2/bot/message/reply', {
      method: 'post', contentType: 'application/json', muteHttpExceptions: true,
      headers: { Authorization: 'Bearer ' + token },
      payload: JSON.stringify({ replyToken: ev.replyToken, messages: [
        { type: 'text', text: kind + ' (กดค้างเพื่อคัดลอก) 👇' },
        { type: 'text', text: id },
        { type: 'text', text: 'นำไปใส่ใน Script properties ตามสาขา:\n' + branches }
      ] })
    });
  });
}

function str_(v, max) { return String(v == null ? '' : v).trim().slice(0, max); }
// กันสูตรใน Google Sheets (เช่น =IMPORTXML) จากข้อความที่ลูกค้าพิมพ์
function safe_(s) { return /^[=+\-@]/.test(s) ? "'" + s : s; }
function unsafe_(s) { return String(s == null ? '' : s); }
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** รันครั้งแรกครั้งเดียวจากหน้า Apps Script เพื่อสร้างชีตและขอสิทธิ์ */
function setup() {
  getSheet_();
  if (!PropertiesService.getScriptProperties().getProperty('ADMIN_PIN')) {
    console.log('อย่าลืมตั้ง ADMIN_PIN ใน Project Settings > Script properties');
  }
}
